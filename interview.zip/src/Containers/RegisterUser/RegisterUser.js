import React, { Component } from "react";
import { Container, Row, Col } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import classes from './RegisterUser.css'
class ShippingAddress extends Component {
  state = {
    fullName: null,
    email: null,
    phone: null,
    address: null,
    country: null,
    state: null,
    city: null,
    pincode: null,
    errors: {
      fullName: "",
      email: "",
      phone: "",
      address: "",
      country: "",
      state: "",
      city: "",
      pincode: "",
    },
    userAddress: [],
   
  };

  handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    let errors = this.state.errors;
    const validEmailRegex = RegExp(
      /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i
    );

    switch (name) {
      case "fullName":
        errors.fullName =
          value.length < 0 ? "Full Name must be 5 characters long!" : "";
        break;
      case "email":
        errors.email = validEmailRegex.test(value) ? "" : "Email is not valid!";
        break;
      case "phone":
        errors.phone = value.length < 10 ? "Phone must be 10 digit long!" : "";
        break;
      case "address":
        errors.address =
          value.length < 3 ? "Adress must be atleast 3 characters long!" : "";
        break;
      case "country":
        errors.country =
          value.length < 2 ? "country must be atleasr 1 characters long!" : "";
        break;
      case "state":
        errors.state =
          value.length < 3 ? "State must be 3 characters long!" : "";
        break;
      case "city":
        errors.city = value.length < 3 ? "city must be 3 characters long!" : "";
        break;
      case "pincode":
        errors.pincode =
          value.length < 2 ? "Pincode must be 2 characters long!" : "";
        break;
      default:
        break;
    }
    if (name === "country") {
      if (value !== "India") {
        this.setState({ shippingCharge: true });
      } else {
        this.setState({ shippingCharge: false });
      }
    }

    this.setState({ errors, [name]: value });
  };
  handleSubmit = (event) => {
    event.preventDefault();

    const validateForm = ({ errors, ...rest }) => {
      let valid = true;
      Object.values(errors).forEach((val) => val.length > 0 && (valid = false));
      Object.values(rest).forEach((val) => {
        val == null && (valid = false);
      });
      return valid;
    };
    if (validateForm(this.state)) {
      let payload = {
        name: this.state.fullName,
        email: this.state.email,
        address: this.state.address,
        state: this.state.state,
        city: this.state.city,
        country: this.state.country,
        zipcode: this.state.pincode,
        phone: this.state.phone,
      };
    } else {
      console.info("inValid Form");
    }
  };
  render() {

    return (
      <div>
        <div className="section2 cart-section">
          <Container>
            <div className="boxCart shippingCart">
              <div className="form-container">
                <Form.Group controlId="formGridEmail">
                  <Form.Label>Full Name</Form.Label>
                  <Form.Control
                    className={
                      this.state.errors.fullName.length > 0 ? "errorBox" : ""
                    }
                    type="text"
                    name="fullName"
                    placeholder="Enter name"
                    onChange={this.handleChange}
                  />
                  {this.state.errors.fullName.length > 0 && (
                    <span className={classes.error}>{this.state.errors.fullName}</span>
                  )}
                </Form.Group>
                <Form.Row>
                  <Form.Group as={Col} controlId="formGridEmail">
                    <Form.Label>Email</Form.Label>
                    <Form.Control
                      name="email"
                      className={
                        this.state.errors.email.length > 0 ? "errorBox" : ""
                      }
                      type="email"
                      placeholder="Enter email"
                      onChange={this.handleChange}
                    />
                    {this.state.errors.email.length > 0 && (
                      <span className={classes.error}>{this.state.errors.email}</span>
                    )}
                  </Form.Group>

                  <Form.Group as={Col} controlId="formGridPassword">
                    <Form.Label>Phone</Form.Label>
                    <Form.Control
                      name="phone"
                      className={
                        this.state.errors.phone.length > 0 ? "errorBox" : ""
                      }
                      type="number"
                      placeholder="Phone"
                      onChange={this.handleChange}
                    />
                    {this.state.errors.phone.length > 0 && (
                      <span className={classes.error}>{this.state.errors.phone}</span>
                    )}
                  </Form.Group>
                </Form.Row>

                <Form.Group controlId="exampleForm.ControlTextarea1">
                  <Form.Label>Billing Address</Form.Label>
                  <Form.Control
                    name="address"
                    as="textarea"
                    className={
                      this.state.errors.address.length > 0 ? "errorBox" : ""
                    }
                    rows="3"
                    onChange={this.handleChange}
                  />
                  {this.state.errors.address.length > 0 && (
                    <span className={classes.error}>{this.state.errors.address}</span>
                  )}
                </Form.Group>

                <Form.Row size="lg">
                  <Form.Group as={Col} controlId="formGridCity">
                    <Form.Label>State</Form.Label>
                    <Form.Control
                      name="state"
                      placeholder="State"
                      className={
                        this.state.errors.state.length > 0 ? "errorBox" : ""
                      }
                      onChange={this.handleChange}
                    />
                    {this.state.errors.state.length > 0 && (
                      <span className={classes.error}>{this.state.errors.state}</span>
                    )}
                  </Form.Group>
                </Form.Row>
                <Form.Row>
                  <Form.Group as={Col} controlId="formGridZip">
                    <Form.Label>City</Form.Label>
                    <Form.Control
                      name="city"
                      placeholder="City"
                      type="text"
                      className={
                        this.state.errors.city.length > 0 ? "errorBox" : ""
                      }
                      onChange={this.handleChange}
                    />
                    {this.state.errors.city.length > 0 && (
                      <span className={classes.error}>{this.state.errors.city}</span>
                    )}
                  </Form.Group>
                  <Form.Group as={Col} controlId="formGridZip">
                    <Form.Label>Pin Code</Form.Label>
                    <Form.Control
                      name="pincode"
                      className={
                        this.state.errors.pincode.length > 0 ? "errorBox" : ""
                      }
                      placeholder="Pin code"
                      type="number"
                      onChange={this.handleChange}
                    />
                    {this.state.errors.pincode.length > 0 && (
                      <span className={classes.error}>{this.state.errors.pincode}</span>
                    )}
                  </Form.Group>
                </Form.Row>
              </div>
            </div>
          </Container>
        </div>
      </div>
    );
  }
}

export default ShippingAddress;
