import * as actionTypes from './ActionTypes';

export const hanleOnChangeEvent = (event,id) => {
    return{
        type : actionTypes.INPUT_ONCHANGE,
        event:event,
        id:id
    }
}