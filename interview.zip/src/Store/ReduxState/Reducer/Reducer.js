import * as actionTypes from "../Actions/ActionTypes";

const initalState = {
  orderForm: {
    Username: {
      elementType: "input",
      elementConfig: {
        type: "text",
        placeholder: "Username",
      },
      value: "",
      validation: {
        required: true,
      },
      valid: false,
      touched: false,
    },
    email: {
      elementType: "input",
      elementConfig: {
        type: "email",
        placeholder: "Your E-Mail",
      },
      value: "",
      validation: {
        required: true,
        isEmail: true,
      },
      valid: false,
      touched: false,
    },
    image: {
      elementType: "file",
      elementConfig: {
        type: "file",
        placeholder: "Image",
      },
      value: "",
      validation: {
        required: true,
      },
      valid: false,
      touched: false,
    },
    Address: {
      elementType: "input",
      elementConfig: {
        type: "text",
        placeholder: "Address",
      },
      value: "",
      validation: {
        required: true,
        minLength: 5,
        maxLength: 5,
        isNumeric: true,
      },
      valid: false,
      touched: false,
    },
    Hobbies: {
      elementType: "input",
      elementConfig: {
        type: "text",
        placeholder: "Hobbies",
      },
      value: "",
      validation: {
        required: true,
      },
      valid: false,
      touched: false,
    },
  },
  formIsValid: false,
};

const checkValidation = (value, rules) => {
  let isValid = true;

  if (rules.required) {
    isValid = value.trim() !== "" && isValid;
  }
  if (rules.minLength) {
    isValid = value.length >= 5 && isValid;
  }
  if (rules.maxLength) {
    isValid = value.length <= 5 && isValid;
  }
  return isValid;
};

const Reducer = (state = initalState, action) => {
  switch (action.type) {
    case actionTypes.INPUT_ONCHANGE: {
      debugger;

      let inputIdentifier = action.id;
      const updatedOrderForm = {
        ...state,
      };
      const updatedFormElement = {
        ...updatedOrderForm[inputIdentifier],
      };
      updatedFormElement.value = action.event.target.value;
    //   updatedFormElement.valid = checkValidation(
    //     updatedFormElement.value,
    //     updatedFormElement.validation
    //   );
      updatedFormElement.touched = true;
      updatedOrderForm[inputIdentifier] = updatedFormElement;
      let formIsValid = true;
      for (let inputIdentifier in updatedOrderForm) {
        formIsValid = updatedOrderForm[inputIdentifier].valid && formIsValid;
      }
      console.log(updatedOrderForm)

      return {
          state :updatedOrderForm
      };
     
    }
    default:
        return state;
  }
};

export default Reducer;
