import React from 'react';
import './App.css';
import RegisterUser from './Containers/RegisterUser/RegisterUser'
function App() {
  return (
    <div className="App">
     <RegisterUser />
    </div>
  );
}

export default App;
